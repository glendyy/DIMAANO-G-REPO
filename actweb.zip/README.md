# PHP Modular Website — Include and Regular Expression Validation

## Project files

```text
php_modular_assignment/
├── index.php
├── login.php
├── register.php
├── logout.php
├── includes/
│   ├── header.php
│   ├── navbar.php
│   ├── footer.php
│   └── validation.php
└── assets/
    └── style.css
```

## Requirements covered

- Converted the website pages to PHP.
- Split the header, navigation, footer, and validation helpers into separate files.
- Used PHP `include` to load the header, navigation, and footer.
- Added PHP server-side validation for login and registration.
- Used regular expressions to validate usernames and passwords; email is checked with `FILTER_VALIDATE_EMAIL` and a regular expression.
- Added basic escaping with `htmlspecialchars`.
- Added login/logout flow for demonstration.

## Run with XAMPP

1. Extract the folder into `C:\xampp\htdocs\php_modular_assignment`.
2. Start **Apache** in the XAMPP Control Panel.
3. Open `http://localhost/php_modular_assignment/` in your browser.
4. Register an account, then log in with the same username and password.

## Validation rules

- Username: 3–20 characters; letters, numbers, and underscores only.
- Email: must use a valid email format.
- Password: at least 8 characters, including at least one letter and one number.
- Confirm password: must match the password.

## Important note for the activity

This is a classroom demonstration. Accounts are stored in the PHP session, so they are temporary and will not be saved permanently in a database. Register and log in using the same browser session. For a real application, use a database, HTTPS, CSRF protection, and additional security controls.

## Suggested screenshots for submission

1. Home page (`index.php`).
2. Registration page (`register.php`).
3. Registration errors after submitting invalid data.
4. Login page (`login.php`).
5. Successful login showing the welcome message.
6. Screenshot of the project file structure in your editor.

Add your GitHub repository URL to your submission after pushing the project files.
