<nav class="navbar" aria-label="Main navigation">
    <div class="container nav-inner">
        <a href="index.php">Home</a>
        <a href="login.php">Login</a>
        <a href="register.php">Register</a>
        <?php if (!empty($_SESSION["current_user"])): ?>
            <span class="welcome">Hi, <?= htmlspecialchars($_SESSION["current_user"], ENT_QUOTES, "UTF-8") ?>!</span>
            <a href="logout.php">Logout</a>
        <?php endif; ?>
    </div>
</nav>
