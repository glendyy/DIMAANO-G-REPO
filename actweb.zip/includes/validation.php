<?php
// Reusable server-side validation helpers.
function clean_input(string $value): string {
    return trim($value);
}

function valid_username(string $username): bool {
    // 3–20 characters; letters, numbers, and underscores only.
    return preg_match('/^[A-Za-z0-9_]{3,20}$/', $username) === 1;
}

function valid_email(string $email): bool {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false
        && preg_match('/^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/', $email) === 1;
}

function valid_password(string $password): bool {
    // At least 8 characters, including one letter and one number.
    return preg_match('/^(?=.*[A-Za-z])(?=.*\d).{8,}$/', $password) === 1;
}

function e(string $value): string {
    return htmlspecialchars($value, ENT_QUOTES, "UTF-8");
}
