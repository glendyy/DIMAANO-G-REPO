<?php
session_start();
$pageTitle = "Home";
include __DIR__ . "/includes/header.php";
include __DIR__ . "/includes/navbar.php";
?>
<main class="container">
    <section class="hero">
        <p class="eyebrow">PHP INCLUDE & FORM VALIDATION</p>
        <h1>Welcome to My PHP Website</h1>
        <p>This sample project demonstrates modular PHP code using <code>include</code>, plus login and registration form validation using regular expressions.</p>
        <div class="actions">
            <a class="button" href="login.php">Login</a>
            <a class="button button-outline" href="register.php">Create an account</a>
        </div>
    </section>

    <section class="info-grid">
        <article class="info-card">
            <h2>Modular structure</h2>
            <p>The header, navigation, and footer are stored in separate files and included where needed.</p>
        </article>
        <article class="info-card">
            <h2>Form validation</h2>
            <p>PHP checks required fields and validates email, username, and password formats on the server.</p>
        </article>
        <article class="info-card">
            <h2>Local testing</h2>
            <p>Run the project with XAMPP or WAMP and open it through your local server.</p>
        </article>
    </section>
</main>
<?php include __DIR__ . "/includes/footer.php"; ?>
