<?php
session_start();
require_once __DIR__ . "/includes/validation.php";
$pageTitle = "Login";
$errors = [];
$username = "";

if (!isset($_SESSION["users"])) {
    $_SESSION["users"] = [];
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $username = clean_input($_POST["username"] ?? "");
    $password = $_POST["password"] ?? "";

    if ($username === "") {
        $errors[] = "Username is required.";
    } elseif (!valid_username($username)) {
        $errors[] = "Username must be 3–20 characters and contain only letters, numbers, or underscores.";
    }

    if ($password === "") {
        $errors[] = "Password is required.";
    }

    if (!$errors) {
        $user = $_SESSION["users"][$username] ?? null;
        if ($user && password_verify($password, $user["password"])) {
            session_regenerate_id(true);
            $_SESSION["current_user"] = $username;
            header("Location: index.php");
            exit;
        }
        $errors[] = "Invalid username or password. Register first if you do not have an account.";
    }
}
include __DIR__ . "/includes/header.php";
include __DIR__ . "/includes/navbar.php";
?>
<main class="container narrow">
    <section class="form-card">
        <p class="eyebrow">WELCOME BACK</p>
        <h1>Login</h1>
        <p class="muted">Enter the account details you registered in this browser session.</p>

        <?php if ($errors): ?>
            <div class="alert alert-error" role="alert">
                <strong>Please check the following:</strong>
                <ul><?php foreach ($errors as $error): ?><li><?= e($error) ?></li><?php endforeach; ?></ul>
            </div>
        <?php endif; ?>

        <?php if (!empty($_GET["registered"])): ?>
            <div class="alert alert-success">Registration successful. You can now log in.</div>
        <?php endif; ?>

        <form method="post" action="login.php" novalidate>
            <label for="username">Username</label>
            <input id="username" name="username" type="text" value="<?= e($username) ?>" minlength="3" maxlength="20" autocomplete="username" required>

            <label for="password">Password</label>
            <input id="password" name="password" type="password" autocomplete="current-password" required>

            <button class="button full-width" type="submit">Login</button>
        </form>
        <p class="form-note">No account yet? <a href="register.php">Register here</a>.</p>
    </section>
</main>
<?php include __DIR__ . "/includes/footer.php"; ?>
